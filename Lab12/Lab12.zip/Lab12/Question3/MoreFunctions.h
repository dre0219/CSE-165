#ifndef MORE_FUNCTIONS_H
#define MORE_FUNCTIONS_H
#include <ios>

namespace MyLib {
    void f(){
        std::cout << "f" << std::endl;
    }

    void g(){
        std::cout << "g" << std::endl;
    }
    
    void someFunction(){
        std::cout << "someFunction\n";
    }
}
#endif